SIC Lab - India district dataset (ESRI Shapefile)
https://lab.spatialintelligence.network/ · Spatial Intelligence Collective

Region:    Arunachal Pradesh
Districts: 25
Geometry:  district polygons
CRS:       WGS 84 (EPSG:4326)

FILES
  districts.shp / .shx / .dbf / .prj / .cpg   the shapefile
  data_dictionary.csv                          column -> full variable, label, unit, vintage
  README.txt                                   this file

IMPORTANT - COLUMN NAMES ARE TRUNCATED
  The Shapefile (DBF) format limits column names to 10 characters, so fields
  appear abbreviated (e.g. "literacy_r" = Literacy Rate, "women_over" = Women
  Overweight, "idx_moment" = Economic Momentum index). Use data_dictionary.csv
  to map every column to its full name, human label, unit and data vintage.
  CSV and GeoJSON exports keep the full, untruncated names.

SOURCES & LICENSING
  Open data aggregated by the SIC Lab. Underlying sources include the
  Census of India 2011, NFHS-5, DPIIT, RBI / Economic Survey, NOAA VIIRS
  night-lights, WUSTL ACAG (PM2.5), MoSPI HCES 2023-24 and Natural Earth.
  Free to use with attribution - cite "SIC Lab, Spatial Intelligence Collective"
  and the original sources. Sources are listed in the Lab's Sources panel.
  Composite indices (idx_*) and the geodemographic segment are the Lab's own
  analysis.

  Data by variable: https://lab.spatialintelligence.network/v1/india/meta.json
